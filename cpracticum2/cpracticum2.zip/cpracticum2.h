// C pointers Practicum with malloc and free
// SWEN-250
// Larry Kiser July 11, 2017
// Updated March 20, 2018

// cpracticum2 functions
int is_pointer_in_array( int *p_int_array, int *p_unknown, int num_int_in_array ) ;
unsigned char my_random() ;
int *create_array_of_products( int *p_first, int *p_second, int number_of_entries ) ;
int get_total_and_free( int *pfirst, int number_of_entries ) ;
int fix_bad_code( char *pstring ) ;
